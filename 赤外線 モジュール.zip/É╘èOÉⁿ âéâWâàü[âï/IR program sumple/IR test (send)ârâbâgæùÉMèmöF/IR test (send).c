
#include <16F877A.h>
#fuses HS,NOWDT,NOPUT,NOPROTECT,BROWNOUT,NOLVP
#use delay(CLOCK=20000000)

#byte port_a=5
#byte port_b=6
#byte port_c=7
#byte port_d=8
#byte port_e=9
#use fast_io(a)
#use fast_io(b)
#use fast_io(c)
#use fast_io(d)
#use fast_io(e)


void p0()								//�p���X0
{
	output_low(PIN_D0);
	delay_us(600);						//600us�ҋ@
}


void p1()								//�p���X1
{
	int i;
	
	for(i=0;i<23;i++){
		output_high(PIN_D0);			//13us��Hi
		delay_us(12);
		output_low(PIN_D0);				//13us��Low
		delay_us(11);
	}
}


int main()
{
	
	
	set_tris_a(0);
	set_tris_b(0xff);
	set_tris_c(0);
	set_tris_d(0);
	set_tris_e(0);
	
	
	port_a = 0;
	port_b = 0;
	port_c = 0;
	port_d = 0;
	port_e = 0;
	
	setup_ccp1(CCP_PWM);
	setup_ccp2(CCP_PWM);
	SETUP_TIMER_2(T2_DIV_BY_16,0xFF,1);
	
	
	
	while(1)
	{
		
		
		if(input(PIN_B1) == 1){
			p1(); p1(); p0(); p0(); p1(); p1(); p0(); p1(); p1();			//�o�̓R�[�h1001(ch1)
			delay_ms(20);
		}
		
		if(input(PIN_B2) == 1){
			p1(); p1(); p0(); p1(); p0(); p1(); p0(); p1(); p1();			//�o�̓R�[�h1010(ch2)
			delay_ms(20);
		}
		
		if(input(PIN_B3) == 1){
			p1(); p0(); p1(); p0(); p1(); p0(); p1(); p0(); p1(); p0();	p1(); p0(); p1(); p0(); p1(); p0(); p1(); p0(); p1(); p0();	p1(); p0(); p1(); p0(); p1(); p0(); p1(); p0(); p1(); p1();	p0(); p1();	p1();	//�o�̓R�[�h1011(ch3)
			delay_ms(20);
		}
		
	}
		
}


	