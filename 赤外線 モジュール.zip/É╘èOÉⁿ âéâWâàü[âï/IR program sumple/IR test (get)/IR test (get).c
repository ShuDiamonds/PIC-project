
#include <16F877A.h>
#fuses HS,NOWDT,NOPUT,NOPROTECT,BROWNOUT,NOLVP
#use delay(CLOCK=20000000)

#byte port_a=5
#byte port_b=6
#byte port_c=7
#byte port_d=8
#byte port_e=9
#use fast_io(a)
#use fast_io(b)
#use fast_io(c)
#use fast_io(d)
#use fast_io(e)
//RS232C�̐ݒ�R�}���h
#define RS_BAUD		9600	//Baud-Reat��9600bps
#define RS_TX		PIN_C6	//TX�s����PIN_C6
#define RS_RX		PIN_C7	//RX�s����PIN_C7
//RS232C�̐ݒ�
#use rs232(BAUD = RS_BAUD , XMIT = RS_TX, RCV = RS_RX)

int main()
{
	int d,d1,d2,d3,d4,s=0;
	
	set_tris_a(0);
	set_tris_b(0xff);
	set_tris_c(0);
	set_tris_d(0);
	set_tris_e(0);
	
	
	port_a = 0;
	port_b = 0;
	port_c = 0;
	port_d = 0;
	port_e = 0;
	
	setup_ccp1(CCP_PWM);
	setup_ccp2(CCP_PWM);
	SETUP_TIMER_2(T2_DIV_BY_16,0xFF,1);
	
	//�X�^�[�g�R�[�h�A�f�[�^�R�[�h4�P�^�A�X�g�b�v�R�[�h4�P�^
	
	while(1)
	{
		output_high(PIN_C3);
		while(input(PIN_B1) == 1){}				//���͂�����܂őҋ@
		delay_us(300);
		
		while(1){
			if(input(PIN_B1) == 0){
				delay_us(600);
				output_low(PIN_C3);
				
				if(input(PIN_B1) == 0){				//�f�[�^1�m�F
					d4 = 8;
				}
				delay_us(600);
				
				if(input(PIN_B1) == 0){				//�f�[�^2�m�F
					d3 = 4;
				}
				delay_us(600);
				
				if(input(PIN_B1) == 0){				//�f�[�^3�m�F
					d2 = 2;
				}
				delay_us(600);
				
				if(input(PIN_B1) == 0){				//�f�[�^4�m�F
					d1 = 1;
				}
				delay_us(600);
				
				
				if(input(PIN_B1) == 1){				//�X�g�b�v�R�[�h�m�F	1�łȂ����break
					break;
				}
				delay_us(600);
				
				if(input(PIN_B1) == 0){				//�X�g�b�v�R�[�h�m�F	0
					break;
				}
				delay_us(600);
				
				if(input(PIN_B1) == 1){				//�X�g�b�v�R�[�h�m�F	1
					break;
				}
				delay_us(600);
				
				if(input(PIN_B1) == 1){				//�X�g�b�v�R�[�h�m�F	1
					break;
				}
			}
			
			d=d1+d2+d3+d4;
			if(d==9){			//ch1
			output_high(PIN_D0);
			output_low(PIN_D1);
			output_low(PIN_D2);
				printf("AAA");
			}
			
			if(d==10){			//ch2
				output_low(PIN_D0);
				output_high(PIN_D1);
				output_low(PIN_D2);
				printf("BBB");
			} 
			
			
			if(d==11){			//ch3
				output_low(PIN_D0);
				output_low(PIN_D1);
				output_high(PIN_D2);
				printf("CCC");
			} 
			
			d1=0;
			d2=0;
			d3=0;
			d4=0;
			
		}
		
		
	}
		
}

