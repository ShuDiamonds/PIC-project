
#include <16F877A.h>
#fuses HS,NOWDT,NOPUT,NOPROTECT,BROWNOUT,NOLVP
#use delay(CLOCK=20000000)

#byte port_a=5
#byte port_b=6
#byte port_c=7
#byte port_d=8
#byte port_e=9
#use fast_io(a)
#use fast_io(b)
#use fast_io(c)
#use fast_io(d)
#use fast_io(e)


void p0()								//�p���X0
{
	output_low(PIN_D0);
	delay_us(600);						//600us�ҋ@
}


void p1()								//�p���X1
{
	int i;
	
	for(i=0;i<23;i++){
		output_high(PIN_D0);			//13us��Hi
		delay_us(12);
		output_low(PIN_D0);				//13us��Low
		delay_us(11);
	}
}


int main()
{
	int1 D0=0;
	int1 D1=0;
	int1 D2=0;
	int1 D3=0;
	int1 D4=0;
	int1 D5=0;
	int1 D6=0;
	int1 D7=0;
	char data = 0;
	set_tris_a(0);
	set_tris_b(0xff);
	set_tris_c(0);
	set_tris_d(0);
	set_tris_e(0);
	
	
	port_a = 0;
	port_b = 0;
	port_c = 0;
	port_d = 0;
	port_e = 0;
	/*
	setup_ccp1(CCP_PWM);
	setup_ccp2(CCP_PWM);
	SETUP_TIMER_2(T2_DIV_BY_16,0xFF,1);
	*/
	
	
	while(1)
	{
		data = 'F';				//�f�[�^��M
		//�f�[�^�ϊ�
		D0 = bit_test(data,0);
		D1 = bit_test(data,1);
		D2 = bit_test(data,2);
		D3 = bit_test(data,3);
		D4 = bit_test(data,4);
		D5 = bit_test(data,5);
		D6 = bit_test(data,6);
		D7 = bit_test(data,7);
			
			//�X�^�[�g�r�b�g���M
			p1();	
			//�f�[�^���M
			if(D0){ p1(); }
			else{ p0(); }
			if(D1){ p1(); }
			else{ p0(); }
			if(D2){ p1(); }
			else{ p0(); }
			if(D3){ p1(); }
			else{ p0(); }
			if(D4){ p1(); }
			else{ p0(); }
			if(D5){ p1(); }
			else{ p0(); }
			if(D6){ p1(); }
			else{ p0(); }
			if(D7){ p1(); }
			else{ p0(); }
		delay_ms(20);
		
		/*
		p0();
		p1();
		p0();
		p0();
		p0();
		p0();
		p0();
		p0();
		p0();
		*/
	}
		
}


	