/****************************************************************************
    LCoV library editor for BSch3V
    Copyright (C) 2004-2005 H.Okada (http://www.suigyodo.com/online)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*****************************************************************************/

#pragma once


// PinProperty �_�C�A���O

//class SPin;

class CPinProperty : public CDialog
{
	DECLARE_DYNAMIC(CPinProperty)

public:
	CPinProperty(CWnd* pParent = NULL);   // �W���R���X�g���N�^
	virtual ~CPinProperty();

	//SPin* m_pPin;
	//bool m_bChanged;

	CString m_name;
	CString* m_arrayNum;
	int m_block;
	bool m_hideNum;
	int m_pinType;


protected:
	int m_currentBlock;

// �_�C�A���O �f�[�^
	enum { IDD = IDD_DIALOG_PIN_PROP };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g

	DECLARE_MESSAGE_MAP()
	virtual BOOL OnInitDialog();
	afx_msg void OnEnChangeEditBlock();
public:
	void setBlock(int block);
	void setName(const char* name);
protected:
	virtual void OnOK();
};
