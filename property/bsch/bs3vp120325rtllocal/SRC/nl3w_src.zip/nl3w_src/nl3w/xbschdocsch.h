/****************************************************************************
    BSch3V schematic capture
    Copyright (C) 1997-2005 H.Okada

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*****************************************************************************/

#ifndef XBSCHDOCSCH_H
#define XBSCHDOCSCH_H

#include "xbschdoc.h"


class SXBSchDocSch : public SXBSchDoc
{

public:
	SXBSchDocSch(){};
	~SXBSchDocSch(){};

	//***** �ҏW *****
	//�R�s�[
	//�R�s�[���s��ꂽ�Ƃ���true��Ԃ�
	bool copy();

	//�\��t��
	//�h�L�������g�ɕύX���������Ƃ�true��Ԃ�
	bool paste(const SPoint& pt);

	//�\��t���\���H
	bool canPaste();

	bool findStringCompare(const char* szTarget,const char* sz,bool bMatchWhole,bool bCaseSensitive);

};

#endif
